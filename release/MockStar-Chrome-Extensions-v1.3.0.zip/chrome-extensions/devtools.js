chrome.devtools.panels.create(
  'MockStar',
  'icons/icon16.png',
  'mockstar/index.html'
);
